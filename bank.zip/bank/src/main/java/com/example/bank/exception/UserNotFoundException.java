package com.example.bank.exception;

public class UserNotFoundException extends Exception {
	

}
