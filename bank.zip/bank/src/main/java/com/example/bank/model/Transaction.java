package com.example.bank.model;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Transaction {
	@Id
	private long customerId;
    private Date tranactionDate;
    private long credited;
    private long debited;
    private long balance;
	public long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}
	public Date getTranactionDate() {
		return tranactionDate;
	}
	public void setTranactionDate(Date tranactionDate) {
		this.tranactionDate = tranactionDate;
	}
	public long getCredited() {
		return credited;
	}
	public void setCredited(long credited) {
		this.credited = credited;
	}
	public long getDebited() {
		return debited;
	}
	public void setDebited(long debited) {
		this.debited = debited;
	}
	public long getBalance() {
		return balance;
	}
	public void setBalance(long balance) {
		this.balance = balance;
	}
	public Transaction(long customerId, Date tranactionDate, long credited, long debited, long balance) {
		super();
		this.customerId = customerId;
		this.tranactionDate = tranactionDate;
		this.credited = credited;
		this.debited = debited;
		this.balance = balance;
	}
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}
    
	
	
	
	
    
    

}
