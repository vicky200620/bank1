package com.example.bank.controller;



import java.util.List;
import java.util.Map;

import javax.persistence.NonUniqueResultException;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.bank.model.AccountDetails;
import com.example.bank.services.AccountActivityCheckService;
import com.example.bank.services.BankServices;
import com.example.bank.services.BankSimulationMABCheckService;


@RestController
@RequestMapping("/bank")
public class BankContorller {
	
	@Autowired
	BankServices bankServices;
	
	@Autowired
	AccountActivityCheckService accountActivityCheckService;
	@Autowired
	BankSimulationMABCheckService mabCheck;
	
	@PostMapping("/add")
	public AccountDetails addAccountDetails(@RequestBody @Valid AccountDetails account)
	{
		bankServices.addAccountDetails(account);
		return account;
		
	}
	
	@GetMapping("/get/balance")
	public long getAccountBalance(@RequestBody Map<String,String> json) {
		long n=(long)(bankServices.getAccountBalance(json.get("accountId")));
		System.out.print(n);
		return n;
		
	}
	
	@GetMapping("/positiveaccounts")
	public List<AccountDetails> checkPositiveBalanceAccounts() throws NonUniqueResultException {
		return bankServices.getPositiveAccounts();
		
	}
	
	@GetMapping("/valid")
	public List<AccountDetails> checkValidity() throws NonUniqueResultException
     {
		return accountActivityCheckService.checkActivity();
		
	  }
	
	@GetMapping("/mabcheck")
	public List<AccountDetails>  accountMabCheck() throws NonUniqueResultException
     {
		return mabCheck.mabCheck();
		
	  }

}
