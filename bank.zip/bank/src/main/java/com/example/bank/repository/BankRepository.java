package com.example.bank.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.bank.model.AccountDetails;

public interface BankRepository extends JpaRepository<AccountDetails, String> {
	
	public AccountDetails findByaccountID(String accountId);
	
	//public final static String GET_POSITIVE_BALANCE = "SELECT lr FROM AccountDetails lr WHERE accountBalance>0"
	@Query("from AccountDetails where accountBalance>0") 
	 public Iterable<AccountDetails> getPositiveBalanceAccounts();
	

	  @Query("from AccountDetails where accountState='true'") 
	  public Iterable<AccountDetails> isActiveForThreeYears(); 
	  
	   @Query("from AccountDetails where monthlyAverageBalance>1000") 
		public Iterable<AccountDetails> isMABSatisfied();
		
	 
	 

}