package com.example.bank.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.bank.model.AccountDetails;
import com.example.bank.repository.BankRepository;

@Service
public class BankSimulationMABCheckService {
	
	@Autowired 
	private BankRepository bankRepository;
	
	
	public List<AccountDetails> mabCheck(){
		
		List<AccountDetails> mabCheckList = new ArrayList<>();
		Iterable<AccountDetails> accDetails = bankRepository.isMABSatisfied();
		for (AccountDetails mabCheck : accDetails) {
			mabCheckList.add(mabCheck);
		}
		return mabCheckList;
	}


	
	

}
