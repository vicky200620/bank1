package com.example.bank.services;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.NonUniqueResultException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.bank.model.AccountDetails;
import com.example.bank.repository.BankRepository;

@Service
public class BankServices {
	@Autowired 
	private BankRepository bankRepository;
	
	
	
	public AccountDetails addAccountDetails(AccountDetails accountDetails) {
		// TODO Auto-generated method stub
		AccountDetails a= bankRepository.save(accountDetails);
		return a;
	}
	
	
	public long getAccountBalance(String accountId)
    {
		AccountDetails a=(AccountDetails)bankRepository.findByaccountID(accountId);
		return a.getAccountBalance();
		
	}
	
	
	
	public List<AccountDetails> getPositiveAccounts()  { 
			List<AccountDetails> list=new ArrayList<>();
			Iterable<AccountDetails> customer=bankRepository.getPositiveBalanceAccounts();
			//customerRepo.isActiveForThreeYears().forEach(list::add);
			for(AccountDetails filteredCustomers:customer) 
			{
				list.add(filteredCustomers);
			}
	
			return list;
	
		}
	
	
	
	

}