package com.example.bank.services;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.NonUniqueResultException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.bank.model.AccountDetails;
import com.example.bank.repository.BankRepository;
@Service
public class AccountActivityCheckService {
	
	@Autowired 
	private BankRepository bankRepository;
	



public List<AccountDetails> checkActivity() {
	List<AccountDetails> list=new ArrayList<>();
	Iterable<AccountDetails> customer=bankRepository.isActiveForThreeYears();
	
	for(AccountDetails filteredCustomers:customer) 
	{
		list.add(filteredCustomers);
	}

	return list;
}
}



